package com.gawe.iqrabeta;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    TextView teks;
    private CardView iqra1, iqra2, iqra3, iqra4, iqra5, iqra6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //define card untuk bisa di klik
        iqra1 = (CardView) findViewById(R.id.iqra_1);
        iqra2 = (CardView) findViewById(R.id.iqra_2);
        iqra3 = (CardView) findViewById(R.id.iqra_3);
        iqra4 = (CardView) findViewById(R.id.iqra_4);
        iqra5 = (CardView) findViewById(R.id.iqra_5);
        iqra6 = (CardView) findViewById(R.id.iqra_6);
        // Add klik listener kedalam semua kartu
        iqra1.setOnClickListener(this);
        iqra2.setOnClickListener(this);
        iqra3.setOnClickListener(this);
        iqra4.setOnClickListener(this);
        iqra5.setOnClickListener(this);
        iqra6.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        Intent i;

        switch (v.getId()) {
            case R.id.iqra_1:
                i = new Intent(this, Iqra1.class);
                startActivity(i);
                break;
            case R.id.iqra_2:
                i = new Intent(this, Iqra2.class);
                startActivity(i);
                break;
            case R.id.iqra_3:
                i = new Intent(this, Iqra3.class);
                startActivity(i);
                break;
            case R.id.iqra_4:
                i = new Intent(this, Iqra4.class);
                startActivity(i);
                break;
            case R.id.iqra_5:
                i = new Intent(this, Iqra5.class);
                startActivity(i);
                break;
            case R.id.iqra_6:
                i = new Intent(this, Iqra6.class);
                startActivity(i);
                break;

            default:
                break;
        }


    }
}
