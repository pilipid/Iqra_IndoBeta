package com.gawe.iqrabeta;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Iqra5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iqra5);
    }
}
